#MobiCric
This hack sends cricket score updates "ball by ball" to the user as a text message.
It uses:-
    -Twilio api
    -CricApi
